function calculator(operation){
    let value1 =parseFloat(document.getElementById("Number1").value)
    let value2 =parseFloat(document.getElementById("Number2").value)
    console.log(value1)
    console.log(value2)
    let result;
    let form=document.querySelector("form")
    form.addEventListener("submit",(e)=>{
        e.preventDefault()
    })
    switch(operation){
        case '+':
            result=value1+value2;
            break;
            case '-':
                result=value1-value2;
                break;
                case '*':
                    result=value1*value2;
                    break;
                    case '/':
                        result=value2!==0 ? value1/value2:'Cannot divide by zero';
                        break;
                        default:
                            result="invalid calculator";
    }
    document.getElementById("result").textContent=result;
    console.log(`the final result is:${result}`)
     
}